(* 
   file: a03q01.ml
   name: Christian Elliott
 *)


exception IgnoreCare;;
exception NotImplemented;;

(* end boilerplate *)

let rec power x n =
  if n > 0 then
    x * (power x (n - 1))
  else
    1;;


